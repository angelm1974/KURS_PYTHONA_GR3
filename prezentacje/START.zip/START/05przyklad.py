# Definicja wielu zmiennych w jednej linii, super sprawa
a, b, c = 3, 3.5, "Halo"

# Przypisanie tej samej wartości do wielu zmiennych
ad = bf = de = lol = 8
 