""" def mojafunkcja(parametry):
    #ciało funkcji
    wyrazenie = [1, 2, 3, 4]+parametry
    return wyrazenie


print(mojafunkcja([4,4,4]))


def pobierzDane(user, password):
    print("Nazwa użytkownika", user, "i hasło:", password)
    return True


print(pobierzDane("Olek", "123QWE"))
 """

def zInputem():
    imie = input("Podaj imie : ")
    nazwisko = input("Podaj nazwisko : ")
    return "Stary, masz na imię: " + imie + " a nazywasz się " + nazwisko


print(zInputem())
