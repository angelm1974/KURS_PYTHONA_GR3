zwierze = "slon"
print(zwierze.capitalize())  # Duża pierwsza litera
z=zwierze.center(25)
print(z)

# definiuj string
string = "Python jest fajnym jezykiem?"
substring = "j"

# zlicza po pierwszym 'j' i do ostatniego znaku'
count = string.count(substring, 8, len(string))

# wyświetl ilość zliczeń
print("Ilość j to:", count)

#encoding

string = string.encode('utf-8', 'strict')

print("Enkodowany string: " + string.decode())
print("Dekodowowany String: " + string.decode('cp932', 'strict'))


# tekst kończy się na
str = "Plik pythona ma rozszerzenie .py?"
print(str.endswith("py?"))

#odległość w tabulatorze
txt = "Gdzie\tjest\tpiwo\t?\n Chciałbym się napić!"

print(txt)
print(txt.expandtabs())
print(txt.expandtabs(2))
print(txt.expandtabs(4))
print(txt.expandtabs(10))

#wyszukiwanie w ciągu
str1 = "Plik pythona ma 1 rozszerzenie .py"
str2 = "yth"
str3 = "213"
print(str1.find(str2))
print(str1.find(str2, 5))
print(str1.find(str2, 23))

#czy ciag jest alfanumeryczny
print(str1.isalnum()) # nie jest bo ma spacje
print(str2.isalnum()) # jest
print(str3.isalnum()) # jest
#tylko litery
print(str2.isalpha()) # jest

#tylko cyfry
print(str3.isdigit()) # jest

#łączenie stringów
krotka = ("Jaro", "Antonio", "Zbysio")

x = ";".join(krotka)

print(x)
