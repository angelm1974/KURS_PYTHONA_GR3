import time
import pyservice_scheduler as pss

def hello():
    print('hello')

def spadaj():
    print('spadaj')

sched = pss.Schedule(callback=hello, seconds=5)
sched2 = pss.Schedule(callback=spadaj, seconds=1*60)

while True:
    if sched.can_run():
        sched.run()
    time.sleep(1)
    if sched2.can_run():
        sched2.run()
    time.sleep(1)