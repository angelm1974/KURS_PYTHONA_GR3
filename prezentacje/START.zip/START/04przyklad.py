from math import *

def poleKola(promyk):
    return pi * promyk ** 2


print("pole koła=", ceil(poleKola(22)), "pierwiastek z 4=", sqrt(4))
