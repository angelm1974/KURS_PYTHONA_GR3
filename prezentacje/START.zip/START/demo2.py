v1="Witaj świecie"
v2='Hej kursanci'
print("v1[0]:", v1[0])
print("v1[1:6]:", v1[1:6])

a=3
a=int(a)
b=3
b=float(b)

print(a is b,a,b)