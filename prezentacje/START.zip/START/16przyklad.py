import csv
import time
""" f = open("demofile.txt", "a+")
wartosc=input("Podaj tekst do zapisu:")
f.write(wartosc+"\n")
f = open("demofile.txt", "r")
print(f.read())  """


 
with open('testowy.csv',encoding='UTF8') as csvfile:
        czytnik=csv.reader(csvfile,delimiter=';',quotechar='|')
        for row in czytnik:
            time.sleep(2)
            print(', '.join(row))
