krotka1=('fizyka','chemia',1997,2001)
krotka2=(1,2,3,4,5)
krotka3=("()","w","a","b")
len((1,2,5)) # ilość
(1,2,3,4,5)+(2,3,4,5) #konkatenacja
('Pa',)*7 #mnożenie elementów
#krotka3[3]=""
5 in (3,4,5,1) 
for x in (3,2,5,7):
    print(x)
krotka1[2]
krotka1[-1]
krotka1[2:]
len(krotka2)
max(krotka3)
min(krotka2)
tuple([1,2,4,56])

print(['Pa',]*7)