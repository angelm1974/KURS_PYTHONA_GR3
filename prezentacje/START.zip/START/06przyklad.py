# stringi testowanie niezmiennosci 
a=[1,2,3]
b=[1,2,3]
c= a is b
message = "Witaj świecie"
#message[0] = "p"
message.replace("W","")
print(message.replace("W","")) 
