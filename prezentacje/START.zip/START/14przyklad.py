import abc
from copy import deepcopy
#definicja klas


class Person:
       def __init__(self, name, age=23):
            super(Person, self).__init__()
            self.name = name
            self.age = age
            self.czas = "2019-08-08"
            kolor="czarny"

       def myfunc(self):
                print("Moje imię to: " + str(self.age))

Adam=Person("Adam",37)
Adam.czas="2020-01-18"
Adam.kolor="bialy"
Adam.myfunc()


class Bird(abc.ABC):
    @abc.abstractmethod
    def fly(self):
        pass

class Czlowiek(abc.ABC):
    @abc.abstractmethod
    def PodajImie(self, strImie):
        pass

    @abc.abstractmethod
    def PodajNazwisko(self, strNazwisko):
        pass
    
class Kierownik(Czlowiek):
    def __init__(self):
        self.Imie=""
        self.Nazwisko=""
    
    def PodajImie(self,strImie):
        self.Imie=strImie
        super(Kierownik,self).__init__()
        print(strImie)

    def PodajNazwisko(self,strNazwisko):
        self.Nazwisko=strNazwisko
        super(Kierownik,self).__init__()
        print(strNazwisko)

k=Kierownik()
k.PodajImie("Rafał")
k.PodajNazwisko("Kulok")



class Parrot(Bird):
    def fly(self):
        super(Parrot, self).__init__()
        print("Flying")

p = Parrot()
p.fly()

p1 = Person("Mariusz", 31)
print(p1.name)
print(p1.age)
print(p1.czas)
p1.myfunc()

class p2(Person,Parrot):
    def __init__(self, name, age=12):
        super(p2, self).__init__(name, age)
        Person.wiek=10

p7 = p2("Jan")
print(p7.age)
print(p7.wiek)
p7.fly() 
 

 
