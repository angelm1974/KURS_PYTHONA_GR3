# Taki bajerek - funkcja która liczy sume parzystych literek
def getCount(inputStr):
    return sum(1 for letter in inputStr if letter in 'aioeuyAIOEUY')
print (getCount("Witaj Świecie"))