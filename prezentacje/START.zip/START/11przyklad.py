from random import randrange
liczba = randrange(0,10)

if liczba == 9:
    print("Liczba jest =9")
elif liczba == 7:
    print("Liczba jest =7")
else:
    print("wyswietli się w każdym innym przypadku")

i = 1
while i < 6:
  print(i)
  i += 1