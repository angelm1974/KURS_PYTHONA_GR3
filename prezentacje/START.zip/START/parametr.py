import argparse
ap=argparse.ArgumentParser()
ap.add_argument("-p1","--plik1",type=str,required=True,help="Nazwa pliku")
args=vars(ap.parse_args())
print(args["plik1"])