class First(object):
    def __init__(self, jeden='jeden'):
        super(First, self).__init__()
        self.jeden = jeden
        

    def myfunc(self):
        print('wynik')

 
class Second(object):
    def __init__(self, dwa='dwa'):
        super(Second, self).__init__()
        self.dwa = dwa
        

class Third(First, Second):
    def __init__(self, trzy='trzy'):
        super(Third, self).__init__()
        self.trzy = trzy


p4 = Third()

print(p4.dwa)