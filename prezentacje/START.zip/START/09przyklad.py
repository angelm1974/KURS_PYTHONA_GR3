slownik={'a':'słoń','lis':'krowa',6:'małpa',7:'mrówka'}


print("a" in slownik)