i = 1
while i < 6:
  print(i)
  i += 1

  # while z breakiem
i = 1
while i < 6:
  print(i)
  if i == 3:
    break
  i += 1

  #----------------------------
i = 1
while i < 6:
  print(i)
  i += 1
else:
  print("i nie jest już mniejsze niż 6")



  #pętla forloops

  fruits = ["apple", "banana", "cherry"]
for x in fruits:
  print(x)


#range
x = range(6)
print(x)
for n in x:
  print(n)

#range 
x = range(3, 6)
for n in x:
  print(n)

#range
x=range(0,100,10)
for n in x:
  print(n)