a = 10
b = "Dziesięć"
c = 10.5
d = -11
e = False

print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))

#castowanie
x = int (1) # x będzie wynosić 1
y = int (2.8) # y będzie wynosić 2
z = int ("3") # z będzie wynosić 3
x = float (1) # x wyniesie 1,0
y = float (2.8) # y będzie wynosić 2.8
z = float ("3") # z będzie 3.0
w = float ("4.2") # w będzie 4.2
x = str ("s1") # x będzie „s1”
y = str (2) # y będzie „2”
z = str (3.0) # z będzie „3.0”