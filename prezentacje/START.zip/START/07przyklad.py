#Przykład dotyczy list
# sposoby definicji 

lista1 = ['fizyka', 'chemia', 213, 1.4]
lista2 = [1, 2, 3, 4, 5, 6]
lista3 = ["a", "B", "c", "d", "e"]
len([1, 2, 3])  # Długość listy
lista4 = lista1+lista2  # łączenie list
lista5=["cześć"]*5 #pomnożenie liczby elementów
4 in [4,2,5,1,5,7] # to już wiecie :D

#to jest fajne
for x in [1,2,3,4,5,6]:
    print(x) # ciało pętli - konieczne jest wcięcie

owoce=["jabłko","gruszka","śliwka","winogrona","czereśnia"]
print(owoce[1])
print(owoce[-2])
print(owoce[1:])

print(min(owoce))

owoce.append('brzoskwinia')

owoce.insert(1,"pomelo")
print(owoce.count("brzoskwinia"))
print(owoce)
print(list.pop(owoce))
owoce.remove("pomelo")
print(owoce)

def mojaFunkcja(e):
    return len(e)
    
samochody=['Ford','Mitsubishi','BMW','VW']
samochody.sort(key=mojaFunkcja, reverse=True)
print(samochody)

